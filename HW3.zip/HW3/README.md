# Summary
I did all the requirements on the Requirements Checklist.

Due to I reawrite the whole JS file, I can not meet all the requirements on exercise 2 and exercise 1.

I did double check and make sure all the function in the Requirements Checklist will work!